#include <stack>
#include <iostream>
#include <deque>
#include <queue>
#include <algorithm>


void main() {



}